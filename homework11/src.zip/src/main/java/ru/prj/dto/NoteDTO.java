package ru.prj.dto;

public record NoteDTO(String title, String content) {}

