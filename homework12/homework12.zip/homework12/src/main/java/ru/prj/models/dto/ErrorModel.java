package ru.prj.models.dto;

public record ErrorModel(String message) {
}
