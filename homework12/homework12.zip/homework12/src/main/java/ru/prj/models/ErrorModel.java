package ru.prj.models;

public record ErrorModel(String message) {
}
