package ru.prj.models.dto;

public record StudentRequest(String fullName, String email) {
}
